public class Server {

	public int id;
	public String type;
	public int limit;
	public int bootupTime;
	public float rate;
	public int coreCount;
	public int memory;
	public int disk;
	public int state;
	public int availableTime;

	Server(int id, String tipe, int lim, int boot, float rate, int core, int mem, int disk) {
		this.id = id;
		this.type = tipe;
		this.limit = lim;
		this.bootupTime = boot;
		this.rate = rate;
		this.coreCount = core;
		this.memory = mem;
		this.disk = disk;
	}

	Server(String tipe, int id, int state, int availTime, int core, int mem, int disk) {
		this.type = tipe;
		this.id = id;
		this.state = state;
		this.availableTime = availTime;
		this.coreCount = core;
		this.memory = mem;
		this.disk = disk;
	}
}